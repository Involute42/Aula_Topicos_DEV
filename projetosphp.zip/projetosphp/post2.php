<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Atividade_01</title>
    <meta charset="utf-8"/>
</head>
<body>
    <form action="atividade1.php" method="post">
        <p>
            Insira o Valor 1: <input type="number" name="valor1" required>
        </p>
        <p>
            Insira o Valor 2: <input type="number" name="valor2" required>
        </p>
        <p>
            <input type="submit" value="Enviar">
        </p>
    </form>
</body>
</html>
