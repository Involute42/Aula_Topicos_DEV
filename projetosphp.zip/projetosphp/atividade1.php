<?php
// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se os valores existem e são números válidos
    if (isset($_POST['valor1'], $_POST['valor2']) && is_numeric($_POST['valor1']) && is_numeric($_POST['valor2'])) {
        $valor1 = $_POST['valor1'];
        $valor2 = $_POST['valor2'];

        // Soma os valores
        $resultado = $valor1 + $valor2;

        // Exibe mensagens separadas
        if ($resultado > 50) {
            echo "A soma dos valores eh maior que 50!";
        } elseif ($resultado == 50) {
            echo "A soma dos valores eh igual a 50!";
        } else {
            echo "A soma dos valores eh menor que 50!";
        }
    } else {
        // Mensagem de erro caso os dados sejam inválidos
        echo "Por favor, insira dois números válidos.";
    }
}
?>
