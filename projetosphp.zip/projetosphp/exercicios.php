<?php
if (isset($_POST['exercise'])) {
    $exercise = $_POST['exercise'];
} else {
    $exercise = '';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Exercícios em PHP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }
        h1 {
            text-align: center;
        }
        select, input, button {
            display: block;
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .result {
            background: #e7f3e7;
            padding: 10px;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Lista de Exercícios</h1>
        <form method="post">
            <label for="exercise">Escolha o exercício:</label>
            <select name="exercise" id="exercise" onchange="this.form.submit()">
                <option value="">Selecione um exercício</option>
                <option value="1" <?php if ($exercise == '1') echo 'selected'; ?>>1. Soma de 2 números</option>
                <option value="2" <?php if ($exercise == '2') echo 'selected'; ?>>2. Subtração e multiplicação</option>
                <option value="3" <?php if ($exercise == '3') echo 'selected'; ?>>3. Soma de 5 números e média</option>
                <option value="4" <?php if ($exercise == '4') echo 'selected'; ?>>4. Soma de 3 valores com condição</option>
                <option value="5" <?php if ($exercise == '5') echo 'selected'; ?>>5. Média de 4 notas com aprovação</option>
                <option value="6" <?php if ($exercise == '6') echo 'selected'; ?>>6. Soma de 5 números, média e primeiros valores</option>
                <option value="7" <?php if ($exercise == '7') echo 'selected'; ?>>7. Idade e categoria de carteira</option>
                <option value="8" <?php if ($exercise == '8') echo 'selected'; ?>>8. Soma de 3 valores e divisão</option>
                <option value="9" <?php if ($exercise == '9') echo 'selected'; ?>>9. Média de 4 notas com aprovação por 70%</option>
                <option value="10" <?php if ($exercise == '10') echo 'selected'; ?>>10. Tabuada de um número</option>
                <option value="11" <?php if ($exercise == '11') echo 'selected'; ?>>11. Soma dos números pares entre 1 e 85</option>
                <option value="12" <?php if ($exercise == '12') echo 'selected'; ?>>12. Cadastro de produto com desconto</option>
                <option value="13" <?php if ($exercise == '13') echo 'selected'; ?>>13. Cálculo de IMC</option>
                <option value="14" <?php if ($exercise == '14') echo 'selected'; ?>>14. Cálculo de IMC com classificação</option>
            </select>
        </form>

        <?php if ($exercise): ?>
            <h2>Exercício <?php echo $exercise; ?></h2>
            <form method="post">
                <input type="hidden" name="exercise" value="<?php echo $exercise; ?>">
                <?php
                switch ($exercise) {
                    case '1':
                    case '2':
                        echo '<label>Digite o primeiro número: <input type="number" name="num1" required></label>';
                        echo '<label>Digite o segundo número: <input type="number" name="num2" required></label>';
                        break;
                    case '3':
                    case '6':
                        for ($i = 1; $i <= 5; $i++) {
                            echo "<label>Número $i: <input type='number' name='num$i' required></label>";
                        }
                        break;
                    case '4':
                    case '8':
                        for ($i = 1; $i <= 3; $i++) {
                            echo "<label>Valor $i: <input type='number' name='num$i' required></label>";
                        }
                        break;
                    case '5':
                    case '9':
                        for ($i = 1; $i <= 4; $i++) {
                            echo "<label>Nota $i: <input type='number' step='0.1' name='nota$i' required></label>";
                        }
                        break;
                    case '7':
                        echo '<label>Informe sua idade: <input type="number" name="idade" required></label>';
                        break;
                    case '10':
                        echo '<label>Digite um número para a tabuada: <input type="number" name="numero" required></label>';
                        break;
                    case '11':
                        echo '<p>A soma dos números pares entre 1 e 85 será exibida ao enviar.</p>';
                        break;
                    case '12':
                        echo '<label>Nome do produto: <input type="text" name="produto" required></label>';
                        echo '<label>Valor do produto: <input type="number" step="0.01" name="valor" required></label>';
                        echo '<label>Percentual de desconto: <input type="number" step="0.1" name="desconto" required></label>';
                        break;
                    case '13':
                    case '14':
                        echo '<label>Peso (kg): <input type="number" step="0.1" name="peso" required></label>';
                        echo '<label>Altura (m): <input type="number" step="0.01" name="altura" required></label>';
                        break;
                }
                ?>
                <button type="submit" name="submit">Enviar</button>
            </form>
        <?php endif; ?>

        <?php
        if (isset($_POST['submit'])) {
            echo '<div class="result"><h3>Resultado:</h3>';
            switch ($exercise) {
                case '1':
                    $soma = $_POST['num1'] + $_POST['num2'];
                    echo "A soma é: $soma";
                    break;
                case '2':
                    $resultado = ($_POST['num1'] - $_POST['num2']) * 5;
                    echo "O resultado é: $resultado";
                    break;
                case '3':
                case '6':
                    $soma = 0;
                    for ($i = 1; $i <= 5; $i++) {
                        $soma += $_POST["num$i"];
                    }
                    $media = $soma / 5;
                    echo "Média: $media<br>Primeiro número: {$_POST['num1']}<br>Segundo número: {$_POST['num2']}";
                    break;
                case '4':
                    $soma = $_POST['num1'] + $_POST['num2'] + $_POST['num3'];
                    echo $soma >= 80 ? "Resultado: $soma - Maior ou igual a 80." : "Resultado: $soma - Menor que 80.";
                    break;
                case '5':
                case '9':
                    $soma = $_POST['nota1'] + $_POST['nota2'] + $_POST['nota3'] + $_POST['nota4'];
                    $media = $soma / 4;
                    $aprovacao = ($exercise == '5') ? 7.0 : 70;
                    $status = ($media >= $aprovacao) ? 'Aprovado' : 'Reprovado';
                    echo "Média: $media - $status";
                    break;
                case '7':
                    $idade = $_POST['idade'];
                    if ($idade >= 21) echo 'Pode fazer carteira AB e D.';
                    elseif ($idade >= 18) echo 'Pode fazer carteira AB.';
                    else echo 'Ainda não tem idade suficiente.';
                    break;
                case '8':
                    $soma = $_POST['num1'] + $_POST['num2'] + $_POST['num3'];
                    $divisao = $soma / $_POST['num2'];
                    echo $divisao >= $_POST['num1'] ? "Resultado: $divisao - Maior ou igual ao primeiro valor." : "Resultado: $divisao - Menor que o primeiro valor.";
                    break;
                case '10':
                    $numero = $_POST['numero'];
                    for ($i = 1; $i <= 10; $i++) {
                        echo "$numero x $i = " . ($numero * $i) . "<br>";
                    }
                    break;
                case '11':
                    $soma = 0;
                    for ($i = 2; $i <= 85; $i += 2) {
                        $soma += $i;
                    }
                    echo "Soma dos números pares entre 1 e 85: $soma";
                    break;
                case '12':
                    $valor_final = $_POST['valor'] - ($_POST['valor'] * ($_POST['desconto'] / 100));
                    echo "Produto: {$_POST['produto']}<br>Preço com desconto: R$" . number_format($valor_final, 2, ',', '.');
                    break;
                case '13':
                case '14':
                    $imc = $_POST['peso'] / (pow($_POST['altura'], 2));
                    echo "IMC: " . number_format($imc, 2);
                    if ($exercise == '14') {
                        if ($imc < 18.5) echo ' - Abaixo do peso';
                        elseif ($imc < 25) echo ' - Peso normal';
                        elseif ($imc < 30) echo ' - Sobrepeso';
                        else echo ' - Obesidade';
                    }
                    break;
            }
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>
