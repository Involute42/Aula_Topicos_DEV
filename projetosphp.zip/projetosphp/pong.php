<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Pong 2D em PHP</title>
    <style>
        body {
            background-color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        canvas {
            background-color: #333;
            border: 4px solid white;
        }
    </style>
</head>
<body>
    <canvas id="pong" width="600" height="400"></canvas>

    <script>
        const canvas = document.getElementById('pong');
        const ctx = canvas.getContext('2d');

        // Desenhar retângulo
        function drawRect(x, y, w, h, color) {
            ctx.fillStyle = color;
            ctx.fillRect(x, y, w, h);
        }

        // Desenhar círculo
        function drawCircle(x, y, r, color) {
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, r, 0, Math.PI * 2, false);
            ctx.closePath();
            ctx.fill();
        }

        // Jogador
        const player = {
            x: 0,
            y: canvas.height / 2 - 50,
            width: 10,
            height: 100,
            color: 'white',
            score: 0
        };

        // Computador
        const computer = {
            x: canvas.width - 10,
            y: canvas.height / 2 - 50,
            width: 10,
            height: 100,
            color: 'white',
            score: 0
        };

        // Bola
        const ball = {
            x: canvas.width / 2,
            y: canvas.height / 2,
            radius: 10,
            speed: 5,
            velocityX: 5,
            velocityY: 5,
            color: 'white'
        };

        // Controlar o jogador
        canvas.addEventListener("mousemove", function(evt) {
            let rect = canvas.getBoundingClientRect();
            player.y = evt.clientY - rect.top - player.height / 2;
        });

        // Resetar a bola
        function resetBall() {
            ball.x = canvas.width / 2;
            ball.y = canvas.height / 2;
            ball.velocityX = -ball.velocityX;
            ball.speed = 5;
        }

        // Detectar colisão
        function collision(b, p) {
            p.top = p.y;
            p.bottom = p.y + p.height;
            p.left = p.x;
            p.right = p.x + p.width;

            b.top = b.y - b.radius;
            b.bottom = b.y + b.radius;
            b.left = b.x - b.radius;
            b.right = b.x + b.radius;

            return p.left < b.right && p.right > b.left && p.top < b.bottom && p.bottom > b.top;
        }

        // Atualizar o jogo
        function update() {
            ball.x += ball.velocityX;
            ball.y += ball.velocityY;

            // Rebater no topo e embaixo
            if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) {
                ball.velocityY = -ball.velocityY;
            }

            // Movimento do computador
            computer.y += (ball.y - (computer.y + computer.height / 2)) * 0.09;

            // Colisão com jogador
            let playerSide = (ball.x < canvas.width / 2) ? player : computer;
            if (collision(ball, playerSide)) {
                ball.velocityX = -ball.velocityX;
                ball.speed += 0.5;
            }

            // Pontuação
            if (ball.x - ball.radius < 0) {
                computer.score++;
                resetBall();
            } else if (ball.x + ball.radius > canvas.width) {
                player.score++;
                resetBall();
            }
        }

        // Desenhar o placar
        function drawText(text, x, y) {
            ctx.fillStyle = "white";
            ctx.font = "45px Arial";
            ctx.fillText(text, x, y);
        }

        // Desenhar elementos
        function render() {
            drawRect(0, 0, canvas.width, canvas.height, "#333");
            drawRect(player.x, player.y, player.width, player.height, player.color);
            drawRect(computer.x, computer.y, computer.width, computer.height, computer.color);
            drawCircle(ball.x, ball.y, ball.radius, ball.color);
            drawText(player.score, canvas.width / 4, canvas.height / 5);
            drawText(computer.score, 3 * canvas.width / 4, canvas.height / 5);
        }

        // Loop do jogo
        function game() {
            update();
            render();
        }

        // Configurar FPS
        const framePerSecond = 60;
        setInterval(game, 1000 / framePerSecond);
    </script>
</body>
</html>
